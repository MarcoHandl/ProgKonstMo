package ue2;

public interface IFood {
	/**
	 * 
	 * @return name of the food
	 */
	public String getName();
	
	/**
	 * 
	 * @return nutritionalValue of the Food
	 */
	public double getKcal();

}
