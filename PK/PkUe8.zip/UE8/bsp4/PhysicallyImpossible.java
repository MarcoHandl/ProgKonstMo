package bsp4;

public class PhysicallyImpossible extends Exception {

	private static final long serialVersionUID = -4143567794385980649L;

}
