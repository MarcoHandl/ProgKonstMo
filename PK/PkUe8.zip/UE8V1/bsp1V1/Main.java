package bsp1V1;

import bsp1.MainSequenceStar;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		
		MainSequenceStar mss1 = new MainSequenceStar(0.5);
		MainSequenceStar mss2 = new MainSequenceStar(1.1);
		MainSequenceStar mss3 = new MainSequenceStar(1.5);
		MainSequenceStar mss4 = new MainSequenceStar(5.1);
		MainSequenceStar mss5 = new MainSequenceStar(7.0);
		
		

	}

}
