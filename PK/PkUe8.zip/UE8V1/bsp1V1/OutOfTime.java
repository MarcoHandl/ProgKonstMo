package bsp1V1;

public class OutOfTime extends Exception {

	private static final long serialVersionUID = -2455629178745925572L;

}
